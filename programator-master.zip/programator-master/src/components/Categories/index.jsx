import React from 'react';
// import Tile from '../Tile';
// import Tiles from '../Tiles';
// style
import './categories.scss';
// import { Container, Row, Col } from 'react-bootstrap';
import { Grid, Row, Col } from 'react-flexbox-grid';
import Card from '../Card';
import { withRouter } from 'react-router-dom';
import ErrorPage from '../ErrorPage';
// import { Modal } from 'react-bootstrap-modal';
import { Modal } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
// import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

class Categories extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // galleryData: this.props.galleryData,
      data: this.props.data,
      isLoading: this.props.isLoading,
      // error: this.props.error,
      move: 0,
      id: null,
      showModal: false,
      newName: ""
    };
  }

  handleHover = (gallery,id) => {
    const { setBGImage } = this.props;
    this.setState({
      move:10,
      id:id
    })
    setBGImage && setTimeout(() => {
      // gallery && gallery.fullpath ? setBGImage(gallery.fullpath) : 
      // gallery && gallery.image && gallery.image.fullpath && setBGImage(gallery.image.fullpath);
      gallery && gallery.image && gallery.image.fullpath && setBGImage(gallery.image.fullpath);
    }, 1000);
  }
  handleLeave = (id) => {
    this.setState({move:0})
  }

  handleClick = (path) => {
    // const { handleClick } = this.props;
    // handleClick && handleClick(path);

    this.state.data && this.state.data.galleries && this.props.history.push(`/gallery/${path}`)
    // TODO: this.state.data && this.state.data.images && openPICTURE
  }

  handleClose = () => {
    this.setState({ showModal: false });
  }
  handleShowModal = () => {
    this.setState({ showModal: true });
  }
  handleChange= (event) => {
    this.setState({newName: event.target.value});
  }
  addGallery = () => {
    // TODO: addGallery modal
    const { addNewGallery } = this.props;
    addNewGallery(this.state.newName);
    this.setState({ showModal: false });
  }


  render(){
    const hoveredCardId = this.state.id;
    const { error, data, isLoading, h1, h2, add} = this.props;
    const cardData = data ? data.galleries ? data.galleries : data.images : null;
    
    if (error) {
      return <ErrorPage
        code={500}
        title="Error"
        description={error.message}
      />
    }
    return(
      <div className="categories">
        
        <h1>{h1}</h1>
        <div style={{display: "flex"}}>
          {this.state.data && this.state.data.images && <span onClick={() => this.props.history.push(`/`)} style={{paddingTop: "25px", paddingRight: "17px"}}>back</span>} 
          <h2>{h2}</h2>
        </div>
        <hr/>


        <Modal show={this.state.showModal && this.state.data && !this.state.data.images} onHide={this.handleClose}
            // size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
          >
          <Modal.Header closeButton>
            <Modal.Title className="categories_x">PRIDAT KATEGORIU</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="categories_pridat">
              <input type="text" className="categories_pridat" placeholder="ZADAJTE NAZOV KATEGORIE" value={this.state.newName} onChange={this.handleChange} />  
              <Button variant="primary" onClick={this.addGallery}>
                + Pridať
                </Button>
            </div>
          </Modal.Body>
        </Modal>

        { isLoading ?
          <p className="loading">Loading ...</p>
          : 
          <Grid fluid className="categories_container">
            <Row>
              {cardData.map( (gallery, id) => 
                <Col 
                  className="card" xs={6} md={3} lg={2} key={id} 
                  onClick={() => this.handleClick(gallery.path)}
                  onMouseEnter={() => this.handleHover(gallery,id)}
                  onMouseLeave={() => this.handleLeave(id)}
                  style={{top: hoveredCardId===id ? -this.state.move : 0 + 'px'}} 
                  >
                    { this.state.data && this.state.data.images ?
                      <Card
                        fullpath = {gallery.fullpath && gallery.fullpath}
                        id = {id}
                      />
                    :
                      <Card
                        name = {gallery.name && gallery.name}
                        path = {gallery.image && gallery.image.fullpath && gallery.image.fullpath}
                        id = {id}
                      />
                    }
                </Col>
              )}
              
              <Col 
                className="card" xs={6} md={3} lg={2}
                onClick={() => this.handleShowModal()}
                onMouseEnter={() => this.handleHover(null,-1)}
                onMouseLeave={() => this.handleLeave(-1)}
                style={{top: hoveredCardId===-1 ? -this.state.move : 0 + 'px'}} 
                >
                  <Card
                    name = {add}
                    path = {null}
                    id = {-1}
                  />
              </Col>
            </Row>
          </Grid>
        }
      </div>
    );
  }
};

export default withRouter(Categories);
