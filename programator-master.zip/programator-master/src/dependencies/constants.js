export const API_URL = "http://api.programator.sk";
export const API_GALLERY_URL = API_URL+"/gallery";
export const API_IMAGES_URL = API_URL+"/images";
export const API_IMAGES_FULL_SIZE_URL = API_URL+"/images/0x0/";
export const API_IMAGES_SMALL_SIZE_URL = API_URL+"/images/215x0/";