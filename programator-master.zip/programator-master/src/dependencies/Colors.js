const Colors = {
    gray: '#555555',
    grayLight: '#aaaaaa',
    
    atramentDark: '#152630',
    atrament: '#1e3b4d',
    brownishDark: '#2c2d2f',
    brownish: '#414043',
    blueDark: '#0a72a3',
    blue: '#11a9d4',
    green: '#00bea1',
    greenLight: '#79da80',
    managerDark: '#151521',
    manager: '#1d1d27',
    yellow: '#efcb4f',
    orange: '#ef9a4f',
    red: '#d0314b',
    purple: '#8f3458',
    black: "#183340",
    grayLine: '#f2f2f2',
    grayDark: '#979797',
    disabledGray: '#bfbfbf'
}
export default Colors;
