## ÚROVEŇ

FE app from folowing specs:
http://www.programator.sk/spoznaj-svoju-uroven

## 1st sprint

### working features

adding gallery,
viewing galleries and its content