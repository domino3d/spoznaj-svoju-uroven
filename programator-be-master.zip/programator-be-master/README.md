# spoznaj-svoju-uroven-be

1st sprint

## working endpoints

/gallery GET POST
/gallery/{path} DELETE