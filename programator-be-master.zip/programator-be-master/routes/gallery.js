var express = require('express');
var router = express.Router();
// var data = require('../resources/data');
// console.log(data.gallery);
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')
const adapter = new FileSync('./resources/db.json')
const db = low(adapter)
const DB_NAME = "galleries"


// GET 
router.get('/', function(req, res, next) {
  if(db.has(DB_NAME).value()){
    var data = db.get(DB_NAME).value()
    res.send({
      galleries:data
    });
  } else {
      
    res.status(500);
    res.send("Nedefinovaná chyba");
  }
});

// POST
router.post('/', function(req, res, next) {
  try {
    if(req.body && req.body.name){

      var name = req.body.name
      // Vytvorenie novej galérie. Názov galérie nemôže obsahovať znak /
      if(name.search("/")!=-1) throw Error()

      var path = encodeURIComponent(name)
      
      if(db.get(DB_NAME)
        .find({ path: path })
        .value()){
          // 409
          res.status(409)
          res.send("Galéria so zadaným názvom už existuje");
        } else {
          // 201
          res.status(201)
          // Add a post
          var d = { path: path, name: name}
          db.get(DB_NAME)
            .push(d)
            .write()
          res.send(d);
        }
      } else {
        res.status(400);
        res.send({
          "code": 400,
          "payload": {
            "paths": ["name"],
            "validator": "required",
            "example": null
          },
          "name": "INVALID_SCHEMA",
          "description": "Bad JSON object: u'name' is a required property"
        });
      }
    } catch (error) {
      res.status(500);
      res.send("Nedefinovaná chyba");
    }
});

/* DELETE */
router.delete('/:path', function(req, res, next) {
    try {
      if(req.params && req.params.path){
  
        var name = req.params.path
        var path = encodeURIComponent(name)
        
        if(!db.get(DB_NAME)
          .find({ path: path })
          .value()){
            // 404
            res.status(404)
            res.send("Zvolená galéria/obrázok neexistuje");
          } else {
            // 200
            res.status(200)
            db.get(DB_NAME)
              .remove({ path: path })
              .write()
            res.send("Galéria/obrázok bola úspešne vymazaná");
          }
        } else {
          res.status(500);
          res.send("Nedefinovaná chyba");
        }
      } catch (error) {
        res.status(500);
        res.send("Nedefinovaná chyba");
      }

});

module.exports = router;

